// File: src/com/vehiclemanagement/utils/DatabaseConnection.java

package com.vehiclemanagement.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // Database URL
    private static final String URL = "jdbc:mysql://localhost:3306/vehicle_management_system?useSSL=false&serverTimezone=UTC";
    // Database credentials
    private static final String USER = "root";
    private static final String PASSWORD = "pRATIK@16?.";

    private static Connection connection = null;

    // Private constructor to prevent instantiation
    private DatabaseConnection() {}

    public static Connection getConnection() {
        if (connection == null) {
            try {
                // Load MySQL JDBC Driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establish the connection
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Database connected successfully.");

            } catch (ClassNotFoundException e) {
                System.err.println("MySQL JDBC Driver not found.");
                e.printStackTrace();
            } catch (SQLException e) {
                System.err.println("Connection failed.");
                e.printStackTrace();
            }
        }
        return connection;
    }
}

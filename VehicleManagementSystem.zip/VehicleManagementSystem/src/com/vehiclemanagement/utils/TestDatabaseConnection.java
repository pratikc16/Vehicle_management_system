// File: src/com/vehiclemanagement/utils/TestDatabaseConnection.java

package com.vehiclemanagement.utils;

import java.sql.Connection;

public class TestDatabaseConnection {
    public static void main(String[] args) {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            System.out.println("Connection test successful.");
        } else {
            System.out.println("Connection test failed.");
        }
    }
}

// File: src/com/vehiclemanagement/database/Database.java

package com.vehiclemanagement.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
    private static Connection connection;

    public static Connection getConnection() {
        if (connection == null) {
            try {
                // Replace with your database URL, username, and password
                String url = "jdbc:mysql://localhost:3306/vehicle_management_system";
                String user = "root";
                String password = "pRATIK@16?.";

                // Optional: Register the JDBC driver
                // Class.forName("com.mysql.cj.jdbc.Driver");

                connection = DriverManager.getConnection(url, user, password);
                System.out.println("Database connected successfully.");
            } catch (SQLException e) {
                System.err.println("Cannot connect to the database: " + e.getMessage());
            }
        }
        return connection;
    }
}

package com.vehiclemanagement.gui;

import com.vehiclemanagement.models.Fine;
import com.vehiclemanagement.services.FineService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.util.List;

/**
 * Controller class for FinesView.fxml.
 * Manages the display and operations related to fines.
 */
public class FinesViewController {

    @FXML
    private TableView<Fine> finesTable;

    @FXML
    private TableColumn<Fine, Integer> fineIdColumn;

    @FXML
    private TableColumn<Fine, Integer> vehicleIdColumn;

    @FXML
    private TableColumn<Fine, String> descriptionColumn;

    @FXML
    private TableColumn<Fine, Double> amountColumn;

    @FXML
    private TableColumn<Fine, String> dateIssuedColumn;

    @FXML
    private Button addFineButton;

    @FXML
    private Button editFineButton;

    @FXML
    private Button deleteFineButton;

    private FineService fineService;

    private ObservableList<Fine> fineData;

    @FXML
    private void initialize() {
        fineService = new FineService();

        // Initialize table columns
        fineIdColumn.setCellValueFactory(cellData -> cellData.getValue().fineIdProperty().asObject());
        vehicleIdColumn.setCellValueFactory(cellData -> cellData.getValue().vehicleIdProperty().asObject());
        descriptionColumn.setCellValueFactory(cellData -> cellData.getValue().descriptionProperty());
        amountColumn.setCellValueFactory(cellData -> cellData.getValue().amountProperty().asObject());
        dateIssuedColumn.setCellValueFactory(cellData -> cellData.getValue().dateIssuedProperty().asString());

        // Load fine data
        loadFineData();

        // Set selection listener
        finesTable.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> updateButtons(newValue)
        );

        // Initially disable edit and delete buttons
        editFineButton.setDisable(true);
        deleteFineButton.setDisable(true);
    }

    /**
     * Loads fine data from the database and populates the table.
     */
    private void loadFineData() {
        List<Fine> fines = fineService.getAllFines();
        fineData = FXCollections.observableArrayList(fines);
        finesTable.setItems(fineData);
    }

    /**
     * Updates the state of the edit and delete buttons based on selection.
     *
     * @param selectedFine The currently selected fine.
     */
    private void updateButtons(Fine selectedFine) {
        boolean disable = selectedFine == null;
        editFineButton.setDisable(disable);
        deleteFineButton.setDisable(disable);
    }

    /**
     * Handles the action when the "Add Fine" button is clicked.
     * Opens the AddFineDialog.
     */
    @FXML
    private void handleAddFine() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AddFineDialog.fxml"));
            Parent root = loader.load();

            AddFineDialogController controller = loader.getController();

            Stage stage = new Stage();
            stage.setTitle("Add Fine");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            // Refresh the fine data after adding
            loadFineData();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Error", "Could not load the Add Fine dialog.");
        }
    }

    /**
     * Handles the action when the "Edit Fine" button is clicked.
     * Opens the EditFineDialog with the selected fine's data.
     */
    @FXML
    private void handleEditFine() {
        Fine selectedFine = finesTable.getSelectionModel().getSelectedItem();
        if (selectedFine == null) {
            showAlert(AlertType.WARNING, "No Selection", "No Fine Selected", "Please select a fine to edit.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("EditFineDialog.fxml"));
            Parent root = loader.load();

            EditFineDialogController controller = loader.getController();
            controller.setFine(selectedFine);

            Stage stage = new Stage();
            stage.setTitle("Edit Fine");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            // Refresh the fine data after editing
            loadFineData();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Error", "Could not load the Edit Fine dialog.");
        }
    }

    /**
     * Handles the action when the "Delete Fine" button is clicked.
     * Prompts the user for confirmation and deletes the selected fine.
     */
    @FXML
    private void handleDeleteFine() {
        Fine selectedFine = finesTable.getSelectionModel().getSelectedItem();
        if (selectedFine == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "No Fine Selected", "Please select a fine to delete.");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Delete Confirmation");
        confirmation.setHeaderText("Are you sure you want to delete the selected fine?");
        confirmation.setContentText("This action cannot be undone.");

        if (confirmation.showAndWait().get() == ButtonType.OK) {
            boolean success = fineService.deleteFine(selectedFine.getFineId());
            if (success) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Fine Deleted", "The fine was deleted successfully.");
                loadFineData();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Deletion Failed", "Could not delete the fine. Please try again.");
            }
        }
    }

    /**
     * Utility method to display alerts.
     *
     * @param alertType The type of the alert.
     * @param title     The title of the alert window.
     * @param header    The header text of the alert.
     * @param content   The content text of the alert.
     */
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        if (header != null && !header.isEmpty()) {
            alert.setHeaderText(header);
        } else {
            alert.setHeaderText(null);
        }
        alert.setContentText(content);
        alert.showAndWait();
    }
}

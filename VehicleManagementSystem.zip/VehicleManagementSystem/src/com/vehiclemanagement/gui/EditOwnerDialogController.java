package com.vehiclemanagement.gui;

import com.vehiclemanagement.models.Owner;
import com.vehiclemanagement.services.OwnerService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

/**
 * Controller class for the EditOwnerDialog.fxml.
 * Manages the editing of existing owners in the system.
 */
public class EditOwnerDialogController {

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField addressField;

    @FXML
    private TextField phoneNumberField;

    @FXML
    private TextField emailField;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private OwnerService ownerService;
    private Owner ownerToEdit;

    @FXML
    private void initialize() {
        ownerService = new OwnerService();
    }

    /**
     * Sets the owner to be edited and populates the form with its details.
     *
     * @param owner The Owner object to edit.
     */
    public void setOwner(Owner owner) {
        this.ownerToEdit = owner;
        populateFields();
    }

    /**
     * Populates the form fields with the owner's current details.
     */
    private void populateFields() {
        if (ownerToEdit != null) {
            firstNameField.setText(ownerToEdit.getFirstName());
            lastNameField.setText(ownerToEdit.getLastName());
            addressField.setText(ownerToEdit.getAddress());
            phoneNumberField.setText(ownerToEdit.getPhoneNumber());
            emailField.setText(ownerToEdit.getEmail());
        }
    }

    /**
     * Handles the action when the "Save" button is clicked.
     * Validates input and updates the owner in the database.
     */
    @FXML
    private void handleSave() {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String address = addressField.getText().trim();
        String phoneNumber = phoneNumberField.getText().trim();
        String email = emailField.getText().trim();

        // Input Validation
        if (firstName.isEmpty() || lastName.isEmpty() || address.isEmpty()
                || phoneNumber.isEmpty() || email.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Missing Fields",
                    "Please fill in all fields.");
            return;
        }

        if (!isValidEmail(email)) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Invalid Email",
                    "Please enter a valid email address.");
            return;
        }

        if (!isValidPhoneNumber(phoneNumber)) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Invalid Phone Number",
                    "Please enter a valid phone number (e.g., 123-456-7890).");
            return;
        }

        // Update the Owner object
        ownerToEdit.setFirstName(firstName);
        ownerToEdit.setLastName(lastName);
        ownerToEdit.setAddress(address);
        ownerToEdit.setPhoneNumber(phoneNumber);
        ownerToEdit.setEmail(email);

        // Update the owner in the database
        boolean success = ownerService.updateOwner(ownerToEdit);

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Success", "Owner Updated",
                    "The owner has been updated successfully.");
            closeDialog();
        } else {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to Update Owner",
                    "An error occurred while updating the owner. Please try again.");
        }
    }

    /**
     * Handles the action when the "Cancel" button is clicked.
     * Closes the dialog without saving.
     */
    @FXML
    private void handleCancel() {
        closeDialog();
    }

    /**
     * Utility method to display alerts.
     *
     * @param alertType The type of the alert.
     * @param title     The title of the alert window.
     * @param header    The header text of the alert.
     * @param content   The content text of the alert.
     */
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        if (header != null && !header.isEmpty()) {
            alert.setHeaderText(header);
        } else {
            alert.setHeaderText(null);
        }
        alert.setContentText(content);
        alert.showAndWait();
    }

    /**
     * Closes the current dialog window.
     */
    private void closeDialog() {
        Stage stage = (Stage) saveButton.getScene().getWindow();
        stage.close();
    }

    /**
     * Validates the email format.
     *
     * @param email The email string to validate.
     * @return True if valid, false otherwise.
     */
    private boolean isValidEmail(String email) {
        // Simple regex for email validation
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        return email.matches(emailRegex);
    }

    /**
     * Validates the phone number format.
     *
     * @param phoneNumber The phone number string to validate.
     * @return True if valid, false otherwise.
     */
    private boolean isValidPhoneNumber(String phoneNumber) {
        // Simple regex for phone number validation (e.g., 123-456-7890)
        String phoneRegex = "^\\d{3}-\\d{3}-\\d{4}$";
        return phoneNumber.matches(phoneRegex);
    }
}

package com.vehiclemanagement.gui;

import com.vehiclemanagement.models.Vehicle;
import com.vehiclemanagement.services.VehicleService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

/**
 * Controller class for the AddVehicleDialog.fxml.
 * Manages the addition of new vehicles to the system.
 */
public class AddVehicleDialogController {

    @FXML
    private TextField ownerIdField;

    @FXML
    private TextField makeField;

    @FXML
    private TextField modelField;

    @FXML
    private TextField yearField;

    @FXML
    private TextField licensePlateField;

    @FXML
    private TextField colorField;

    @FXML
    private TextField driverIdField;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private VehicleService vehicleService;

    @FXML
    private void initialize() {
        vehicleService = new VehicleService();
    }

    /**
     * Handles the action when the "Save" button is clicked.
     * Validates input and adds the new vehicle to the database.
     */
    @FXML
    private void handleSave() {
        String ownerIdText = ownerIdField.getText().trim();
        String make = makeField.getText().trim();
        String model = modelField.getText().trim();
        String yearText = yearField.getText().trim();
        String licensePlate = licensePlateField.getText().trim();
        String color = colorField.getText().trim();
        String driverIdText = driverIdField.getText().trim();

        // Input Validation
        if (ownerIdText.isEmpty() || make.isEmpty() || model.isEmpty()
                || yearText.isEmpty() || licensePlate.isEmpty() || color.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Missing Fields",
                    "Please fill in all required fields.");
            return;
        }

        int ownerId;
        int year;
        int driverId = 0; // Default to 0 if not provided

        try {
            ownerId = Integer.parseInt(ownerIdText);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Invalid Owner ID",
                    "Owner ID must be a valid integer.");
            return;
        }

        try {
            year = Integer.parseInt(yearText);
            if (year < 1886 || year > 3000) { // Considering the first car was invented around 1886
                throw new NumberFormatException("Year out of realistic range.");
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Invalid Year",
                    "Please enter a valid year (e.g., 2020).");
            return;
        }

        if (!driverIdText.isEmpty()) {
            try {
                driverId = Integer.parseInt(driverIdText);
            } catch (NumberFormatException e) {
                showAlert(Alert.AlertType.ERROR, "Validation Error", "Invalid Driver ID",
                        "Driver ID must be a valid integer.");
                return;
            }
        }

        // Create a new Vehicle object
        Vehicle newVehicle = new Vehicle();
        newVehicle.setOwnerId(ownerId);
        newVehicle.setMake(make);
        newVehicle.setModel(model);
        newVehicle.setYear(year);
        newVehicle.setLicensePlate(licensePlate);
        newVehicle.setColor(color);
        newVehicle.setDriverId(driverId);

        // Add the vehicle to the database
        boolean success = vehicleService.addVehicle(newVehicle);

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Success", "Vehicle Added",
                    "The vehicle has been added successfully.");
            closeDialog();
        } else {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to Add Vehicle",
                    "An error occurred while adding the vehicle. Please ensure that the Owner ID and Driver ID exist.");
        }
    }

    /**
     * Handles the action when the "Cancel" button is clicked.
     * Closes the dialog without saving.
     */
    @FXML
    private void handleCancel() {
        closeDialog();
    }

    /**
     * Utility method to display alerts.
     *
     * @param alertType The type of the alert.
     * @param title     The title of the alert window.
     * @param header    The header text of the alert.
     * @param content   The content text of the alert.
     */
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        if (header != null && !header.isEmpty()) {
            alert.setHeaderText(header);
        } else {
            alert.setHeaderText(null);
        }
        alert.setContentText(content);
        alert.showAndWait();
    }

    /**
     * Closes the current dialog window.
     */
    private void closeDialog() {
        Stage stage = (Stage) saveButton.getScene().getWindow();
        stage.close();
    }
}

package com.vehiclemanagement.gui;

import com.vehiclemanagement.models.Fine;
import com.vehiclemanagement.services.FineService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.time.LocalDate;

/**
 * Controller class for the AddFineDialog.fxml.
 * Manages the addition of new fines to the system.
 */
public class AddFineDialogController {

    @FXML
    private TextField vehicleIdField;

    @FXML
    private TextField descriptionField;

    @FXML
    private TextField amountField;

    @FXML
    private DatePicker dateIssuedField;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private FineService fineService;

    @FXML
    private void initialize() {
        fineService = new FineService();
    }

    /**
     * Handles the action when the "Save" button is clicked.
     * Validates input and adds the new fine to the database.
     */
    @FXML
    private void handleSave() {
        String vehicleIdText = vehicleIdField.getText().trim();
        String description = descriptionField.getText().trim();
        String amountText = amountField.getText().trim();
        LocalDate dateIssued = dateIssuedField.getValue();

        if (vehicleIdText.isEmpty() || description.isEmpty() || amountText.isEmpty() || dateIssued == null) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Missing Fields", "Please fill in all fields.");
            return;
        }

        int vehicleId;
        double amount;

        try {
            vehicleId = Integer.parseInt(vehicleIdText);
            amount = Double.parseDouble(amountText);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Invalid Input", "Please enter valid numbers for Vehicle ID and Amount.");
            return;
        }

        // Create a new Fine object
        Fine newFine = new Fine();
        newFine.setVehicleId(vehicleId);
        newFine.setDescription(description);
        newFine.setAmount(amount);
        newFine.setDateIssued(dateIssued);

        // Add the fine to the database
        boolean success = fineService.addFine(newFine);

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Success", "Fine Added", "The fine has been added successfully.");
            closeDialog();
        } else {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to Add Fine", "An error occurred while adding the fine.");
        }
    }

    /**
     * Handles the action when the "Cancel" button is clicked.
     * Closes the dialog without saving.
     */
    @FXML
    private void handleCancel() {
        closeDialog();
    }

    /**
     * Closes the current dialog window.
     */
    private void closeDialog() {
        Stage stage = (Stage) saveButton.getScene().getWindow();
        stage.close();
    }

    /**
     * Utility method to display alerts.
     *
     * @param alertType The type of the alert.
     * @param title     The title of the alert window.
     * @param header    The header text of the alert.
     * @param content   The content text of the alert.
     */
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

package com.vehiclemanagement.gui;

import com.vehiclemanagement.models.Vehicle;
import com.vehiclemanagement.services.VehicleService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.util.List;

/**
 * Controller class for the VehiclesView.fxml.
 * Manages the display and operations related to vehicles.
 */
public class VehiclesViewController {

    @FXML
    private TableView<Vehicle> vehiclesTable;

    @FXML
    private TableColumn<Vehicle, Integer> vehicleIdColumn;

    @FXML
    private TableColumn<Vehicle, Integer> ownerIdColumn;

    @FXML
    private TableColumn<Vehicle, String> makeColumn;

    @FXML
    private TableColumn<Vehicle, String> modelColumn;

    @FXML
    private TableColumn<Vehicle, Integer> yearColumn;

    @FXML
    private TableColumn<Vehicle, String> licensePlateColumn;

    @FXML
    private TableColumn<Vehicle, String> colorColumn;

    @FXML
    private TableColumn<Vehicle, Integer> driverIdColumn;

    @FXML
    private Button addVehicleButton;

    @FXML
    private Button editVehicleButton;

    @FXML
    private Button deleteVehicleButton;

    private VehicleService vehicleService;

    private ObservableList<Vehicle> vehicleData;

    @FXML
    private void initialize() {
        vehicleService = new VehicleService();

        // Initialize the table columns.
        vehicleIdColumn.setCellValueFactory(new PropertyValueFactory<>("vehicleId"));
        ownerIdColumn.setCellValueFactory(new PropertyValueFactory<>("ownerId"));
        makeColumn.setCellValueFactory(new PropertyValueFactory<>("make"));
        modelColumn.setCellValueFactory(new PropertyValueFactory<>("model"));
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("year"));
        licensePlateColumn.setCellValueFactory(new PropertyValueFactory<>("licensePlate"));
        colorColumn.setCellValueFactory(new PropertyValueFactory<>("color"));
        driverIdColumn.setCellValueFactory(new PropertyValueFactory<>("driverId"));

        // Load vehicle data
        loadVehicleData();

        // Set selection listener
        vehiclesTable.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> updateButtons(newValue)
        );

        // Initially disable edit and delete buttons
        editVehicleButton.setDisable(true);
        deleteVehicleButton.setDisable(true);
    }

    /**
     * Loads vehicle data from the database and populates the table.
     */
    private void loadVehicleData() {
        List<Vehicle> vehicles = vehicleService.getAllVehicles();
        vehicleData = FXCollections.observableArrayList(vehicles);
        vehiclesTable.setItems(vehicleData);
    }

    /**
     * Updates the state of the edit and delete buttons based on selection.
     *
     * @param selectedVehicle The currently selected vehicle.
     */
    private void updateButtons(Vehicle selectedVehicle) {
        boolean disable = selectedVehicle == null;
        editVehicleButton.setDisable(disable);
        deleteVehicleButton.setDisable(disable);
    }

    /**
     * Handles the action when the "Add Vehicle" button is clicked.
     * Opens the AddVehicleDialog.
     */
    @FXML
    private void handleAddVehicle() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AddVehicleDialog.fxml"));
            Parent root = loader.load();

            AddVehicleDialogController controller = loader.getController();

            Stage stage = new Stage();
            stage.setTitle("Add Vehicle");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            // Refresh the vehicle data after adding
            loadVehicleData();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Error", "Could not load the Add Vehicle dialog.");
        }
    }

    /**
     * Handles the action when the "Edit Vehicle" button is clicked.
     * Opens the EditVehicleDialog with selected vehicle's data.
     */
    @FXML
    private void handleEditVehicle() {
        Vehicle selectedVehicle = vehiclesTable.getSelectionModel().getSelectedItem();
        if (selectedVehicle == null) {
            showAlert(AlertType.WARNING, "No Selection", "No Vehicle Selected", "Please select a vehicle to edit.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("EditVehicleDialog.fxml"));
            Parent root = loader.load();

            EditVehicleDialogController controller = loader.getController();
            controller.setVehicle(selectedVehicle);

            Stage stage = new Stage();
            stage.setTitle("Edit Vehicle");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            // Refresh the vehicle data after editing
            loadVehicleData();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Error", "Could not load the Edit Vehicle dialog.");
        }
    }

    /**
     * Handles the action when the "Delete Vehicle" button is clicked.
     * Prompts the user for confirmation and deletes the selected vehicle.
     */
    @FXML
    private void handleDeleteVehicle() {
        Vehicle selectedVehicle = vehiclesTable.getSelectionModel().getSelectedItem();
        if (selectedVehicle == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "No Vehicle Selected", "Please select a vehicle to delete.");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Delete Confirmation");
        confirmation.setHeaderText("Are you sure you want to delete the selected vehicle?");
        confirmation.setContentText("This action cannot be undone.");

        if (confirmation.showAndWait().get() == ButtonType.OK) {
            boolean success = vehicleService.deleteVehicle(selectedVehicle.getVehicleId());
            if (success) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Vehicle Deleted", "The vehicle was deleted successfully.");
                loadVehicleData();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Deletion Failed", "Could not delete the vehicle. Please try again.");
            }
        }
    }

    /**
     * Utility method to display alerts.
     *
     * @param alertType The type of the alert.
     * @param title     The title of the alert window.
     * @param header    The header text of the alert.
     * @param content   The content text of the alert.
     */
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        if (header != null && !header.isEmpty()) {
            alert.setHeaderText(header);
        } else {
            alert.setHeaderText(null);
        }
        alert.setContentText(content);
        alert.showAndWait();
    }
}

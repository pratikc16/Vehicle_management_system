package com.vehiclemanagement.gui;

import com.vehiclemanagement.models.Driver;
import com.vehiclemanagement.services.DriverService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.util.List;

/**
 * Controller class for DriversView.fxml.
 * Manages the display and operations related to drivers.
 */
public class DriversViewController {

    @FXML
    private TableView<Driver> driversTable;

    @FXML
    private TableColumn<Driver, Integer> driverIdColumn;

    @FXML
    private TableColumn<Driver, String> firstNameColumn;

    @FXML
    private TableColumn<Driver, String> lastNameColumn;

    @FXML
    private TableColumn<Driver, String> licenseNumberColumn;

    @FXML
    private TableColumn<Driver, String> phoneNumberColumn;

    @FXML
    private TableColumn<Driver, String> emailColumn;

    @FXML
    private Button addDriverButton;

    @FXML
    private Button editDriverButton;

    @FXML
    private Button deleteDriverButton;

    private DriverService driverService;

    private ObservableList<Driver> driverData;

    @FXML
    private void initialize() {
        driverService = new DriverService();

        // Initialize table columns
        driverIdColumn.setCellValueFactory(cellData -> cellData.getValue().driverIdProperty().asObject());
        firstNameColumn.setCellValueFactory(cellData -> cellData.getValue().firstNameProperty());
        lastNameColumn.setCellValueFactory(cellData -> cellData.getValue().lastNameProperty());
        licenseNumberColumn.setCellValueFactory(cellData -> cellData.getValue().licenseNumberProperty());
        phoneNumberColumn.setCellValueFactory(cellData -> cellData.getValue().phoneNumberProperty());
        emailColumn.setCellValueFactory(cellData -> cellData.getValue().emailProperty());

        // Load driver data
        loadDriverData();

        // Set selection listener
        driversTable.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> updateButtons(newValue)
        );

        // Initially disable edit and delete buttons
        editDriverButton.setDisable(true);
        deleteDriverButton.setDisable(true);
    }

    /**
     * Loads driver data from the database and populates the table.
     */
    private void loadDriverData() {
        List<Driver> drivers = driverService.getAllDrivers();
        driverData = FXCollections.observableArrayList(drivers);
        driversTable.setItems(driverData);
    }

    /**
     * Updates the state of the edit and delete buttons based on selection.
     *
     * @param selectedDriver The currently selected driver.
     */
    private void updateButtons(Driver selectedDriver) {
        boolean disable = selectedDriver == null;
        editDriverButton.setDisable(disable);
        deleteDriverButton.setDisable(disable);
    }

    /**
     * Handles the action when the "Add Driver" button is clicked.
     * Opens the AddDriverDialog.
     */
    @FXML
    private void handleAddDriver() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AddDriverDialog.fxml"));
            Parent root = loader.load();

            AddDriverDialogController controller = loader.getController();

            Stage stage = new Stage();
            stage.setTitle("Add Driver");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            // Refresh the driver data after adding
            loadDriverData();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Error", "Could not load the Add Driver dialog.");
        }
    }

    /**
     * Handles the action when the "Edit Driver" button is clicked.
     * Opens the EditDriverDialog with selected driver's data.
     */
    @FXML
    private void handleEditDriver() {
        Driver selectedDriver = driversTable.getSelectionModel().getSelectedItem();
        if (selectedDriver == null) {
            showAlert(AlertType.WARNING, "No Selection", "No Driver Selected", "Please select a driver to edit.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("EditDriverDialog.fxml"));
            Parent root = loader.load();

            EditDriverDialogController controller = loader.getController();
            controller.setDriver(selectedDriver);

            Stage stage = new Stage();
            stage.setTitle("Edit Driver");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            // Refresh the driver data after editing
            loadDriverData();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Error", "Could not load the Edit Driver dialog.");
        }
    }

    /**
     * Handles the action when the "Delete Driver" button is clicked.
     * Prompts the user for confirmation and deletes the selected driver.
     */
    @FXML
    private void handleDeleteDriver() {
        Driver selectedDriver = driversTable.getSelectionModel().getSelectedItem();
        if (selectedDriver == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "No Driver Selected", "Please select a driver to delete.");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Delete Confirmation");
        confirmation.setHeaderText("Are you sure you want to delete the selected driver?");
        confirmation.setContentText("This action cannot be undone.");

        if (confirmation.showAndWait().get() == ButtonType.OK) {
            boolean success = driverService.deleteDriver(selectedDriver.getDriverId());
            if (success) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Driver Deleted", "The driver was deleted successfully.");
                loadDriverData();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Deletion Failed", "Could not delete the driver. Please try again.");
            }
        }
    }

    /**
     * Utility method to display alerts.
     *
     * @param alertType The type of the alert.
     * @param title     The title of the alert window.
     * @param header    The header text of the alert.
     * @param content   The content text of the alert.
     */
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        if (header != null && !header.isEmpty()) {
            alert.setHeaderText(header);
        } else {
            alert.setHeaderText(null);
        }
        alert.setContentText(content);
        alert.showAndWait();
    }
}

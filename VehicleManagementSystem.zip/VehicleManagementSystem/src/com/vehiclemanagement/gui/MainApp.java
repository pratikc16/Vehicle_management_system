package com.vehiclemanagement.gui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;

/**
 * The MainApp class serves as the entry point for the Vehicle Management System.
 * It initializes the JavaFX application and sets up the primary stage with a tabbed interface
 * to manage Owners, Vehicles, Drivers, and Fines.
 */
public class MainApp extends Application {

    /**
     * The start method is called after the application is launched.
     * It sets up the primary stage with a TabPane containing the Owners, Vehicles, Drivers, and Fines views.
     *
     * @param primaryStage The primary stage for this application.
     */
    @Override
    public void start(Stage primaryStage) {
        try {
            // Set the title of the primary stage
            primaryStage.setTitle("Vehicle Management System");

            // Create a TabPane to hold different tabs
            TabPane tabPane = new TabPane();

            // Initialize the Owners Tab
            Tab ownersTab = createTab("Owners", "/com/vehiclemanagement/gui/OwnersView.fxml");
            tabPane.getTabs().add(ownersTab);

            // Initialize the Vehicles Tab
            Tab vehiclesTab = createTab("Vehicles", "/com/vehiclemanagement/gui/VehiclesView.fxml");
            tabPane.getTabs().add(vehiclesTab);

            // Initialize the Drivers Tab
            Tab driversTab = createTab("Drivers", "/com/vehiclemanagement/gui/DriversView.fxml");
            tabPane.getTabs().add(driversTab);

            // Initialize the Fines Tab (Newly added)
            Tab finesTab = createTab("Fines", "/com/vehiclemanagement/gui/FinesView.fxml");
            tabPane.getTabs().add(finesTab);

            // Create the scene with the TabPane as the root node
            Scene scene = new Scene(tabPane, 1000, 700); // Adjust width and height as needed

            // Set the scene to the primary stage
            primaryStage.setScene(scene);

            // Display the primary stage
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
            // In a production application, consider logging this exception and showing a user-friendly message
        }
    }

    /**
     * Creates a new Tab with the specified title and loads the corresponding FXML content.
     *
     * @param title    The title of the tab.
     * @param fxmlPath The path to the FXML file to load as the tab's content.
     * @return A Tab object with the loaded content.
     */
    private Tab createTab(String title, String fxmlPath) {
        Tab tab = new Tab(title);
        tab.setClosable(false); // Prevents the user from closing the tab

        try {
            // Load the FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent content = loader.load();

            // Set the loaded content to the tab
            tab.setContent(content);
        } catch (Exception e) {
            e.printStackTrace();
            // If FXML fails to load, display an error message within the tab
            tab.setContent(new Label("Failed to load " + title + " view."));
        }

        return tab;
    }

    /**
     * The main method is ignored in correctly deployed JavaFX applications.
     * main() serves as fallback in case the application cannot be launched through deployment artifacts.
     *
     * @param args The command line arguments.
     */
    public static void main(String[] args) {
        launch(args);
    }
}

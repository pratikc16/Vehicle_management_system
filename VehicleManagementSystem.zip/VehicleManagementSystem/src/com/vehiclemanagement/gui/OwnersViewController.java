package com.vehiclemanagement.gui;

import com.vehiclemanagement.models.Owner;
import com.vehiclemanagement.services.OwnerService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.util.List;

/**
 * Controller class for the OwnersView.fxml.
 * Manages the display and operations related to owners.
 */
public class OwnersViewController {

    @FXML
    private TableView<Owner> ownersTable;

    @FXML
    private TableColumn<Owner, Integer> ownerIdColumn;

    @FXML
    private TableColumn<Owner, String> firstNameColumn;

    @FXML
    private TableColumn<Owner, String> lastNameColumn;

    @FXML
    private TableColumn<Owner, String> addressColumn;

    @FXML
    private TableColumn<Owner, String> phoneNumberColumn;

    @FXML
    private TableColumn<Owner, String> emailColumn;

    @FXML
    private Button addOwnerButton;

    @FXML
    private Button editOwnerButton;

    @FXML
    private Button deleteOwnerButton;

    private OwnerService ownerService;

    private ObservableList<Owner> ownerData;

    @FXML
    private void initialize() {
        ownerService = new OwnerService();

        // Initialize the table columns.
        ownerIdColumn.setCellValueFactory(new PropertyValueFactory<>("ownerId"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        phoneNumberColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));

        // Load owner data
        loadOwnerData();

        // Set selection listener
        ownersTable.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> updateButtons(newValue)
        );

        // Initially disable edit and delete buttons
        editOwnerButton.setDisable(true);
        deleteOwnerButton.setDisable(true);
    }

    /**
     * Loads owner data from the database and populates the table.
     */
    private void loadOwnerData() {
        List<Owner> owners = ownerService.getAllOwners();
        ownerData = FXCollections.observableArrayList(owners);
        ownersTable.setItems(ownerData);
    }

    /**
     * Updates the state of the edit and delete buttons based on selection.
     *
     * @param selectedOwner The currently selected owner.
     */
    private void updateButtons(Owner selectedOwner) {
        boolean disable = selectedOwner == null;
        editOwnerButton.setDisable(disable);
        deleteOwnerButton.setDisable(disable);
    }

    /**
     * Handles the action when the "Add Owner" button is clicked.
     * Opens the AddOwnerDialog.
     */
    @FXML
    private void handleAddOwner() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AddOwnerDialog.fxml"));
            Parent root = loader.load();

            AddOwnerDialogController controller = loader.getController();

            Stage stage = new Stage();
            stage.setTitle("Add Owner");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            // Refresh the owner data after adding
            loadOwnerData();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Error", "Could not load the Add Owner dialog.");
        }
    }

    /**
     * Handles the action when the "Edit Owner" button is clicked.
     * Opens the EditOwnerDialog with selected owner's data.
     */
    @FXML
    private void handleEditOwner() {
        Owner selectedOwner = ownersTable.getSelectionModel().getSelectedItem();
        if (selectedOwner == null) {
            showAlert(AlertType.WARNING, "No Selection", "No Owner Selected", "Please select an owner to edit.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("EditOwnerDialog.fxml"));
            Parent root = loader.load();

            EditOwnerDialogController controller = loader.getController();
            controller.setOwner(selectedOwner);

            Stage stage = new Stage();
            stage.setTitle("Edit Owner");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            // Refresh the owner data after editing
            loadOwnerData();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Error", "Could not load the Edit Owner dialog.");
        }
    }

    /**
     * Handles the action when the "Delete Owner" button is clicked.
     * Prompts the user for confirmation and deletes the selected owner.
     */
    @FXML
    private void handleDeleteOwner() {
        Owner selectedOwner = ownersTable.getSelectionModel().getSelectedItem();
        if (selectedOwner == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "No Owner Selected", "Please select an owner to delete.");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Delete Confirmation");
        confirmation.setHeaderText("Are you sure you want to delete the selected owner?");
        confirmation.setContentText("This action cannot be undone.");

        if (confirmation.showAndWait().get() == ButtonType.OK) {
            boolean success = ownerService.deleteOwner(selectedOwner.getOwnerId());
            if (success) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Owner Deleted", "The owner was deleted successfully.");
                loadOwnerData();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Deletion Failed", "Could not delete the owner. Please try again.");
            }
        }
    }

    /**
     * Utility method to display alerts.
     *
     * @param alertType The type of the alert.
     * @param title     The title of the alert window.
     * @param header    The header text of the alert.
     * @param content   The content text of the alert.
     */
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        if (header != null && !header.isEmpty()) {
            alert.setHeaderText(header);
        } else {
            alert.setHeaderText(null);
        }
        alert.setContentText(content);
        alert.showAndWait();
    }
}

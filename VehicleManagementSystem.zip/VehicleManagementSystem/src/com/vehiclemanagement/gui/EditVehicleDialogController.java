package com.vehiclemanagement.gui;

import com.vehiclemanagement.models.Vehicle;
import com.vehiclemanagement.models.Owner;
import com.vehiclemanagement.services.VehicleService;
import com.vehiclemanagement.services.OwnerService;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.StringConverter;

/**
 * Controller class for the EditVehicleDialog.fxml.
 * Manages the editing of existing vehicles in the system.
 */
public class EditVehicleDialogController {

    @FXML
    private ComboBox<Owner> ownerComboBox;

    @FXML
    private TextField makeField;

    @FXML
    private TextField modelField;

    @FXML
    private TextField yearField;

    @FXML
    private TextField licensePlateField;

    @FXML
    private TextField colorField;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private VehicleService vehicleService;
    private OwnerService ownerService;

    private ObservableList<Owner> ownerData;
    private Vehicle vehicleToEdit;

    @FXML
    private void initialize() {
        vehicleService = new VehicleService();
        ownerService = new OwnerService();

        // Initialize the ownerComboBox with Owners
        loadOwners();

        // Set up the license plate field with a prompt
        licensePlateField.setPromptText("e.g., ABC-1234");

        // Set default focus
        makeField.requestFocus();
    }

    /**
     * Loads the list of owners from the database and populates the ownerComboBox.
     */
    private void loadOwners() {
        ownerData = FXCollections.observableArrayList(ownerService.getAllOwners());
        ownerComboBox.setItems(ownerData);

        // Customize the display of owners in the ComboBox
        ownerComboBox.setConverter(new StringConverter<Owner>() {
            @Override
            public String toString(Owner owner) {
                if (owner == null) {
                    return "";
                }
                return owner.getFirstName() + " " + owner.getLastName();
            }

            @Override
            public Owner fromString(String string) {
                return null; // Not needed for ComboBox selection
            }
        });
    }

    /**
     * Sets the vehicle to be edited and populates the form with its details.
     *
     * @param vehicle The Vehicle object to edit.
     */
    public void setVehicle(Vehicle vehicle) {
        this.vehicleToEdit = vehicle;
        populateFields();
    }

    /**
     * Populates the form fields with the vehicle's current details.
     */
    private void populateFields() {
        if (vehicleToEdit != null) {
            ownerComboBox.getSelectionModel().select(getOwnerById(vehicleToEdit.getOwnerId()));
            makeField.setText(vehicleToEdit.getMake());
            modelField.setText(vehicleToEdit.getModel());
            yearField.setText(String.valueOf(vehicleToEdit.getYear()));
            licensePlateField.setText(vehicleToEdit.getLicensePlate());
            colorField.setText(vehicleToEdit.getColor());
        }
    }

    /**
     * Retrieves an Owner object by its ID from the ownerData list.
     *
     * @param ownerId The ID of the owner.
     * @return The Owner object if found, null otherwise.
     */
    private Owner getOwnerById(int ownerId) {
        for (Owner owner : ownerData) {
            if (owner.getOwnerId() == ownerId) {
                return owner;
            }
        }
        return null;
    }

    /**
     * Handles the action when the "Save" button is clicked.
     * Validates input and updates the vehicle in the database.
     */
    @FXML
    private void handleSave() {
        Owner selectedOwner = ownerComboBox.getSelectionModel().getSelectedItem();
        String make = makeField.getText().trim();
        String model = modelField.getText().trim();
        String yearText = yearField.getText().trim();
        String licensePlate = licensePlateField.getText().trim();
        String color = colorField.getText().trim();

        // Input Validation
        if (selectedOwner == null || make.isEmpty() || model.isEmpty() || yearText.isEmpty()
                || licensePlate.isEmpty() || color.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Missing Fields",
                    "Please fill in all fields and select an owner.");
            return;
        }

        int year;
        try {
            year = Integer.parseInt(yearText);
            if (year < 1886 || year > 9999) { // The first automobile was made in 1886
                throw new NumberFormatException("Year out of realistic range.");
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Invalid Year",
                    "Please enter a valid year.");
            return;
        }

        // License Plate Validation (Optional)
        if (!isValidLicensePlate(licensePlate)) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Invalid License Plate",
                    "Please enter a valid license plate (e.g., ABC-1234).");
            return;
        }

        // Update the Vehicle object
        vehicleToEdit.setOwnerId(selectedOwner.getOwnerId());
        vehicleToEdit.setMake(make);
        vehicleToEdit.setModel(model);
        vehicleToEdit.setYear(year);
        vehicleToEdit.setLicensePlate(licensePlate);
        vehicleToEdit.setColor(color);

        // Update the vehicle in the database
        boolean success = vehicleService.updateVehicle(vehicleToEdit);

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Success", "Vehicle Updated",
                    "The vehicle has been updated successfully.");
            closeDialog();
        } else {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to Update Vehicle",
                    "An error occurred while updating the vehicle. Please try again.");
        }
    }

    /**
     * Handles the action when the "Cancel" button is clicked.
     * Closes the dialog without saving.
     */
    @FXML
    private void handleCancel() {
        closeDialog();
    }

    /**
     * Utility method to display alerts.
     *
     * @param alertType The type of the alert.
     * @param title     The title of the alert window.
     * @param header    The header text of the alert.
     * @param content   The content text of the alert.
     */
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        if (header != null && !header.isEmpty()) {
            alert.setHeaderText(header);
        } else {
            alert.setHeaderText(null);
        }
        alert.setContentText(content);
        alert.showAndWait();
    }

    /**
     * Closes the current dialog window.
     */
    private void closeDialog() {
        Stage stage = (Stage) saveButton.getScene().getWindow();
        stage.close();
    }

    /**
     * Validates the license plate format.
     *
     * @param licensePlate The license plate string to validate.
     * @return True if valid, false otherwise.
     */
    private boolean isValidLicensePlate(String licensePlate) {
        // Example regex for license plates: 3 uppercase letters followed by a hyphen and 4 digits (e.g., ABC-1234)
        String licensePlateRegex = "^[A-Z]{3}-\\d{4}$";
        return licensePlate.matches(licensePlateRegex);
    }
}

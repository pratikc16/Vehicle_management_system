package com.vehiclemanagement.gui;

import com.vehiclemanagement.models.Driver;
import com.vehiclemanagement.services.DriverService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

/**
 * Controller class for the AddDriverDialog.fxml.
 * Manages the addition of new drivers to the system.
 */
public class AddDriverDialogController {

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField licenseNumberField;

    @FXML
    private TextField phoneNumberField;

    @FXML
    private TextField emailField;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private DriverService driverService;

    @FXML
    private void initialize() {
        driverService = new DriverService();
    }

    /**
     * Handles the action when the "Save" button is clicked.
     * Validates input and adds the new driver to the database.
     */
    @FXML
    private void handleSave() {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String licenseNumber = licenseNumberField.getText().trim();
        String phoneNumber = phoneNumberField.getText().trim();
        String email = emailField.getText().trim();

        if (firstName.isEmpty() || lastName.isEmpty() || licenseNumber.isEmpty()
                || phoneNumber.isEmpty() || email.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Missing Fields", "Please fill in all fields.");
            return;
        }

        // Create a new Driver object
        Driver newDriver = new Driver();
        newDriver.setFirstName(firstName);
        newDriver.setLastName(lastName);
        newDriver.setLicenseNumber(licenseNumber);
        newDriver.setPhoneNumber(phoneNumber);
        newDriver.setEmail(email);

        // Add the driver to the database
        boolean success = driverService.addDriver(newDriver);

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Success", "Driver Added", "The driver has been added successfully.");
            closeDialog();
        } else {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to Add Driver", "An error occurred while adding the driver.");
        }
    }

    /**
     * Handles the action when the "Cancel" button is clicked.
     * Closes the dialog without saving.
     */
    @FXML
    private void handleCancel() {
        closeDialog();
    }

    /**
     * Closes the current dialog window.
     */
    private void closeDialog() {
        Stage stage = (Stage) saveButton.getScene().getWindow();
        stage.close();
    }

    /**
     * Utility method to display alerts.
     *
     * @param alertType The type of the alert.
     * @param title     The title of the alert window.
     * @param header    The header text of the alert.
     * @param content   The content text of the alert.
     */
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

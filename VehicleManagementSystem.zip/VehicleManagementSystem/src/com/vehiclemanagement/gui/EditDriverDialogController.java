package com.vehiclemanagement.gui;

import com.vehiclemanagement.models.Driver;
import com.vehiclemanagement.services.DriverService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

/**
 * Controller class for the EditDriverDialog.fxml.
 * Manages the editing of existing drivers in the system.
 */
public class EditDriverDialogController {

    @FXML
    private TextField driverIdField;

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField licenseNumberField;

    @FXML
    private TextField phoneNumberField;

    @FXML
    private TextField emailField;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private DriverService driverService;
    private Driver driverToEdit;

    @FXML
    private void initialize() {
        driverService = new DriverService();
    }

    /**
     * Sets the driver to be edited and populates the form fields.
     *
     * @param driver The Driver object to edit.
     */
    public void setDriver(Driver driver) {
        this.driverToEdit = driver;
        populateFields();
    }

    /**
     * Populates the form fields with the driver's current details.
     */
    private void populateFields() {
        if (driverToEdit != null) {
            driverIdField.setText(String.valueOf(driverToEdit.getDriverId()));
            firstNameField.setText(driverToEdit.getFirstName());
            lastNameField.setText(driverToEdit.getLastName());
            licenseNumberField.setText(driverToEdit.getLicenseNumber());
            phoneNumberField.setText(driverToEdit.getPhoneNumber());
            emailField.setText(driverToEdit.getEmail());
        }
    }

    /**
     * Handles the action when the "Save" button is clicked.
     * Validates input and updates the driver in the database.
     */
    @FXML
    private void handleSave() {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String licenseNumber = licenseNumberField.getText().trim();
        String phoneNumber = phoneNumberField.getText().trim();
        String email = emailField.getText().trim();

        if (firstName.isEmpty() || lastName.isEmpty() || licenseNumber.isEmpty()
                || phoneNumber.isEmpty() || email.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Missing Fields", "Please fill in all fields.");
            return;
        }

        // Update the Driver object
        driverToEdit.setFirstName(firstName);
        driverToEdit.setLastName(lastName);
        driverToEdit.setLicenseNumber(licenseNumber);
        driverToEdit.setPhoneNumber(phoneNumber);
        driverToEdit.setEmail(email);

        // Update the driver in the database
        boolean success = driverService.updateDriver(driverToEdit);

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Success", "Driver Updated", "The driver has been updated successfully.");
            closeDialog();
        } else {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to Update Driver", "An error occurred while updating the driver.");
        }
    }

    /**
     * Handles the action when the "Cancel" button is clicked.
     * Closes the dialog without saving.
     */
    @FXML
    private void handleCancel() {
        closeDialog();
    }

    /**
     * Closes the current dialog window.
     */
    private void closeDialog() {
        Stage stage = (Stage) saveButton.getScene().getWindow();
        stage.close();
    }

    /**
     * Utility method to display alerts.
     *
     * @param alertType The type of the alert.
     * @param title     The title of the alert window.
     * @param header    The header text of the alert.
     * @param content   The content text of the alert.
     */
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

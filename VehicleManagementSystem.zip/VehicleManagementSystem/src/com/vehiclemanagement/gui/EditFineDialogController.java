package com.vehiclemanagement.gui;

import com.vehiclemanagement.models.Fine;
import com.vehiclemanagement.services.FineService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.time.LocalDate;

/**
 * Controller class for the EditFineDialog.fxml.
 * Manages the editing of existing fines in the system.
 */
public class EditFineDialogController {

    @FXML
    private TextField fineIdField;

    @FXML
    private TextField vehicleIdField;

    @FXML
    private TextField descriptionField;

    @FXML
    private TextField amountField;

    @FXML
    private DatePicker dateIssuedField;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private FineService fineService;
    private Fine fineToEdit;

    @FXML
    private void initialize() {
        fineService = new FineService();
    }

    /**
     * Sets the fine to be edited and populates the form fields.
     *
     * @param fine The Fine object to edit.
     */
    public void setFine(Fine fine) {
        this.fineToEdit = fine;
        populateFields();
    }

    /**
     * Populates the form fields with the fine's current details.
     */
    private void populateFields() {
        if (fineToEdit != null) {
            fineIdField.setText(String.valueOf(fineToEdit.getFineId()));
            vehicleIdField.setText(String.valueOf(fineToEdit.getVehicleId()));
            descriptionField.setText(fineToEdit.getDescription());
            amountField.setText(String.valueOf(fineToEdit.getAmount()));
            dateIssuedField.setValue(fineToEdit.getDateIssued());
        }
    }

    /**
     * Handles the action when the "Save" button is clicked.
     * Validates input and updates the fine in the database.
     */
    @FXML
    private void handleSave() {
        String vehicleIdText = vehicleIdField.getText().trim();
        String description = descriptionField.getText().trim();
        String amountText = amountField.getText().trim();
        LocalDate dateIssued = dateIssuedField.getValue();

        if (vehicleIdText.isEmpty() || description.isEmpty() || amountText.isEmpty() || dateIssued == null) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Missing Fields", "Please fill in all fields.");
            return;
        }

        int vehicleId;
        double amount;

        try {
            vehicleId = Integer.parseInt(vehicleIdText);
            amount = Double.parseDouble(amountText);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Invalid Input", "Please enter valid numbers for Vehicle ID and Amount.");
            return;
        }

        // Update the Fine object
        fineToEdit.setVehicleId(vehicleId);
        fineToEdit.setDescription(description);
        fineToEdit.setAmount(amount);
        fineToEdit.setDateIssued(dateIssued);

        // Update the fine in the database
        boolean success = fineService.updateFine(fineToEdit);

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Success", "Fine Updated", "The fine has been updated successfully.");
            closeDialog();
        } else {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to Update Fine", "An error occurred while updating the fine.");
        }
    }

    /**
     * Handles the action when the "Cancel" button is clicked.
     * Closes the dialog without saving.
     */
    @FXML
    private void handleCancel() {
        closeDialog();
    }

    /**
     * Closes the current dialog window.
     */
    private void closeDialog() {
        Stage stage = (Stage) saveButton.getScene().getWindow();
        stage.close();
    }

    /**
     * Utility method to display alerts.
     *
     * @param alertType The type of the alert.
     * @param title     The title of the alert window.
     * @param header    The header text of the alert.
     * @param content   The content text of the alert.
     */
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

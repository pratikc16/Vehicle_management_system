// File: src/com/vehiclemanagement/models/ParkingSpot.java

package com.vehiclemanagement.models;

public class ParkingSpot {
    private int spotId;
    private String location;
    private double latitude;
    private double longitude;
    private boolean availability;

    // Default constructor
    public ParkingSpot() {}

    // Parameterized constructor
    public ParkingSpot(int spotId, String location, double latitude, double longitude, boolean availability) {
        this.spotId = spotId;
        this.location = location;
        this.latitude = latitude;
        this.longitude = longitude;
        this.availability = availability;
    }

    // Getters and Setters
    public int getSpotId() {
        return spotId;
    }

    public void setSpotId(int spotId) {
        this.spotId = spotId;
    }

    public String getLocation() {
        return location;
    }
 
    public void setLocation(String location) {
        this.location = location;
    }
 
    public double getLatitude() {
        return latitude;
    }
 
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }
 
    public double getLongitude() {
        return longitude;
    }
 
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
 
    public boolean isAvailability() {
        return availability;
    }
 
    public void setAvailability(boolean availability) {
        this.availability = availability;
    }
}

package com.vehiclemanagement.models;

import javafx.beans.property.*;

/**
 * Represents a Vehicle entity with relevant details.
 */
public class Vehicle {
    private final IntegerProperty vehicleId;
    private final IntegerProperty ownerId;
    private final StringProperty make;
    private final StringProperty model;
    private final IntegerProperty year;
    private final StringProperty licensePlate;
    private final StringProperty color;
    private final IntegerProperty driverId; // To associate a driver with the vehicle

    public Vehicle() {
        this.vehicleId = new SimpleIntegerProperty();
        this.ownerId = new SimpleIntegerProperty();
        this.make = new SimpleStringProperty();
        this.model = new SimpleStringProperty();
        this.year = new SimpleIntegerProperty();
        this.licensePlate = new SimpleStringProperty();
        this.color = new SimpleStringProperty();
        this.driverId = new SimpleIntegerProperty(); // Initialize driverId
    }

    // Getters and Setters

    public int getVehicleId() {
        return vehicleId.get();
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId.set(vehicleId);
    }

    public IntegerProperty vehicleIdProperty() {
        return vehicleId;
    }

    public int getOwnerId() {
        return ownerId.get();
    }

    public void setOwnerId(int ownerId) {
        this.ownerId.set(ownerId);
    }

    public IntegerProperty ownerIdProperty() {
        return ownerId;
    }

    public String getMake() {
        return make.get();
    }

    public void setMake(String make) {
        this.make.set(make);
    }

    public StringProperty makeProperty() {
        return make;
    }

    public String getModel() {
        return model.get();
    }

    public void setModel(String model) {
        this.model.set(model);
    }

    public StringProperty modelProperty() {
        return model;
    }

    public int getYear() {
        return year.get();
    }

    public void setYear(int year) {
        this.year.set(year);
    }

    public IntegerProperty yearProperty() {
        return year;
    }

    public String getLicensePlate() {
        return licensePlate.get();
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate.set(licensePlate);
    }

    public StringProperty licensePlateProperty() {
        return licensePlate;
    }

    public String getColor() {
        return color.get();
    }

    public void setColor(String color) {
        this.color.set(color);
    }

    public StringProperty colorProperty() {
        return color;
    }

    public int getDriverId() {
        return driverId.get();
    }

    public void setDriverId(int driverId) {
        this.driverId.set(driverId);
    }

    public IntegerProperty driverIdProperty() {
        return driverId;
    }
}

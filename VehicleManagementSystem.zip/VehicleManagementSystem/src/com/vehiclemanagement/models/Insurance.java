package com.vehiclemanagement.models;

import javafx.beans.property.*;
import java.time.LocalDate;

/**
 * Represents an Insurance entity associated with a Vehicle.
 */
public class Insurance {
    private final IntegerProperty insuranceId;
    private final IntegerProperty vehicleId;
    private final StringProperty insuranceCompany;
    private final DoubleProperty coverageAmount;
    private final ObjectProperty<LocalDate> startDate;
    private final ObjectProperty<LocalDate> endDate;
    private final StringProperty policyNumber;

    public Insurance() {
        this.insuranceId = new SimpleIntegerProperty();
        this.vehicleId = new SimpleIntegerProperty();
        this.insuranceCompany = new SimpleStringProperty();
        this.coverageAmount = new SimpleDoubleProperty();
        this.startDate = new SimpleObjectProperty<>();
        this.endDate = new SimpleObjectProperty<>();
        this.policyNumber = new SimpleStringProperty();
    }

    // Getters and Setters

    public int getInsuranceId() {
        return insuranceId.get();
    }

    public void setInsuranceId(int insuranceId) {
        this.insuranceId.set(insuranceId);
    }

    public IntegerProperty insuranceIdProperty() {
        return insuranceId;
    }

    public int getVehicleId() {
        return vehicleId.get();
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId.set(vehicleId);
    }

    public IntegerProperty vehicleIdProperty() {
        return vehicleId;
    }

    public String getInsuranceCompany() {
        return insuranceCompany.get();
    }

    public void setInsuranceCompany(String insuranceCompany) {
        this.insuranceCompany.set(insuranceCompany);
    }

    public StringProperty insuranceCompanyProperty() {
        return insuranceCompany;
    }

    public double getCoverageAmount() {
        return coverageAmount.get();
    }

    public void setCoverageAmount(double coverageAmount) {
        this.coverageAmount.set(coverageAmount);
    }

    public DoubleProperty coverageAmountProperty() {
        return coverageAmount;
    }

    public LocalDate getStartDate() {
        return startDate.get();
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate.set(startDate);
    }

    public ObjectProperty<LocalDate> startDateProperty() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate.get();
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate.set(endDate);
    }

    public ObjectProperty<LocalDate> endDateProperty() {
        return endDate;
    }

    public String getPolicyNumber() {
        return policyNumber.get();
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber.set(policyNumber);
    }

    public StringProperty policyNumberProperty() {
        return policyNumber;
    }
}

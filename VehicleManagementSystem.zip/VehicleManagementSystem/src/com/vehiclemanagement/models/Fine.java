package com.vehiclemanagement.models;

import javafx.beans.property.*;

import java.time.LocalDate;

/**
 * Represents a Fine entity with relevant details.
 */
public class Fine {
    private final IntegerProperty fineId;
    private final IntegerProperty vehicleId;
    private final StringProperty description;
    private final DoubleProperty amount;
    private final ObjectProperty<LocalDate> dateIssued;

    public Fine() {
        this.fineId = new SimpleIntegerProperty();
        this.vehicleId = new SimpleIntegerProperty();
        this.description = new SimpleStringProperty();
        this.amount = new SimpleDoubleProperty();
        this.dateIssued = new SimpleObjectProperty<>();
    }

    // Getters and Setters

    public int getFineId() {
        return fineId.get();
    }

    public void setFineId(int fineId) {
        this.fineId.set(fineId);
    }

    public IntegerProperty fineIdProperty() {
        return fineId;
    }

    public int getVehicleId() {
        return vehicleId.get();
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId.set(vehicleId);
    }

    public IntegerProperty vehicleIdProperty() {
        return vehicleId;
    }

    public String getDescription() {
        return description.get();
    }

    public void setDescription(String description) {
        this.description.set(description);
    }

    public StringProperty descriptionProperty() {
        return description;
    }

    public double getAmount() {
        return amount.get();
    }

    public void setAmount(double amount) {
        this.amount.set(amount);
    }

    public DoubleProperty amountProperty() {
        return amount;
    }

    public LocalDate getDateIssued() {
        return dateIssued.get();
    }

    public void setDateIssued(LocalDate dateIssued) {
        this.dateIssued.set(dateIssued);
    }

    public ObjectProperty<LocalDate> dateIssuedProperty() {
        return dateIssued;
    }
}

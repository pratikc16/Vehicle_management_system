package com.vehiclemanagement.services;

import com.vehiclemanagement.daos.VehicleDAO;
import com.vehiclemanagement.models.Vehicle;

import java.util.List;

/**
 * Service class for managing Vehicle-related operations.
 */
public class VehicleService {
    private final VehicleDAO vehicleDAO;

    public VehicleService() {
        this.vehicleDAO = new VehicleDAO();
    }

    /**
     * Adds a new vehicle to the system.
     *
     * @param vehicle The Vehicle object to add.
     * @return True if the vehicle was added successfully, false otherwise.
     */
    public boolean addVehicle(Vehicle vehicle) {
        // Additional business logic can be added here (e.g., validation)
        return vehicleDAO.insert(vehicle);
    }

    /**
     * Retrieves all vehicles from the system.
     *
     * @return A list of all vehicles.
     */
    public List<Vehicle> getAllVehicles() {
        return vehicleDAO.getAll();
    }

    /**
     * Retrieves a vehicle by its unique ID.
     *
     * @param id The unique identifier of the vehicle.
     * @return The Vehicle object if found, null otherwise.
     */
    public Vehicle getVehicleById(int id) {
        return vehicleDAO.getById(id);
    }

    /**
     * Updates an existing vehicle's details.
     *
     * @param vehicle The Vehicle object with updated information.
     * @return True if the update was successful, false otherwise.
     */
    public boolean updateVehicle(Vehicle vehicle) {
        // Additional business logic can be added here (e.g., validation)
        return vehicleDAO.update(vehicle);
    }

    /**
     * Deletes a vehicle from the system.
     *
     * @param id The unique identifier of the vehicle to delete.
     * @return True if the deletion was successful, false otherwise.
     */
    public boolean deleteVehicle(int id) {
        return vehicleDAO.delete(id);
    }
}

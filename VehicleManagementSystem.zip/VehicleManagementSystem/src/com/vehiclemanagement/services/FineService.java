package com.vehiclemanagement.services;

import com.vehiclemanagement.daos.FineDAO;
import com.vehiclemanagement.models.Fine;

import java.util.List;

/**
 * Service class for handling business logic related to fines.
 * Acts as an intermediary between the GUI controllers and the DAO layer.
 */
public class FineService {

    private FineDAO fineDAO;

    public FineService() {
        fineDAO = new FineDAO();
    }

    /**
     * Adds a new fine to the system.
     *
     * @param fine The Fine object to add.
     * @return True if addition was successful, false otherwise.
     */
    public boolean addFine(Fine fine) {
        return fineDAO.insert(fine);
    }

    /**
     * Retrieves all fines in the system.
     *
     * @return A list of all Fine objects.
     */
    public List<Fine> getAllFines() {
        return fineDAO.getAll();
    }

    /**
     * Retrieves a fine by its ID.
     *
     * @param fineId The ID of the fine to retrieve.
     * @return The Fine object if found, null otherwise.
     */
    public Fine getFineById(int fineId) {
        return fineDAO.getById(fineId);
    }

    /**
     * Updates the details of an existing fine.
     *
     * @param fine The Fine object with updated information.
     * @return True if the update was successful, false otherwise.
     */
    public boolean updateFine(Fine fine) {
        return fineDAO.update(fine);
    }

    /**
     * Deletes a fine from the system.
     *
     * @param fineId The ID of the fine to delete.
     * @return True if deletion was successful, false otherwise.
     */
    public boolean deleteFine(int fineId) {
        return fineDAO.delete(fineId);
    }
}

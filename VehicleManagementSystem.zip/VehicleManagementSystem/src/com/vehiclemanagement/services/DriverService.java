package com.vehiclemanagement.services;

import com.vehiclemanagement.daos.DriverDAO;
import com.vehiclemanagement.models.Driver;

import java.util.List;

/**
 * Service class for handling business logic related to drivers.
 * Acts as an intermediary between the GUI controllers and the DAO layer.
 */
public class DriverService {

    private DriverDAO driverDAO;

    public DriverService() {
        driverDAO = new DriverDAO();
    }

    /**
     * Adds a new driver to the system.
     *
     * @param driver The Driver object to add.
     * @return True if addition was successful, false otherwise.
     */
    public boolean addDriver(Driver driver) {
        return driverDAO.insert(driver);
    }

    /**
     * Retrieves all drivers in the system.
     *
     * @return A list of all Driver objects.
     */
    public List<Driver> getAllDrivers() {
        return driverDAO.getAll();
    }

    /**
     * Retrieves a driver by its ID.
     *
     * @param driverId The ID of the driver to retrieve.
     * @return The Driver object if found, null otherwise.
     */
    public Driver getDriverById(int driverId) {
        return driverDAO.getById(driverId);
    }

    /**
     * Updates the details of an existing driver.
     *
     * @param driver The Driver object with updated information.
     * @return True if the update was successful, false otherwise.
     */
    public boolean updateDriver(Driver driver) {
        return driverDAO.update(driver);
    }

    /**
     * Deletes a driver from the system.
     *
     * @param driverId The ID of the driver to delete.
     * @return True if deletion was successful, false otherwise.
     */
    public boolean deleteDriver(int driverId) {
        return driverDAO.delete(driverId);
    }
}

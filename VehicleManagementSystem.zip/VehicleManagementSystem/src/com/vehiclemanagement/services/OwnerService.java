package com.vehiclemanagement.services;

import com.vehiclemanagement.daos.OwnerDAO;
import com.vehiclemanagement.models.Owner;

import java.util.List;

/**
 * Service class for managing Owner-related operations.
 */
public class OwnerService {
    private final OwnerDAO ownerDAO;

    public OwnerService() {
        this.ownerDAO = new OwnerDAO();
    }

    /**
     * Adds a new owner to the system.
     *
     * @param owner The Owner object to add.
     * @return True if the owner was added successfully, false otherwise.
     */
    public boolean addOwner(Owner owner) {
        // Additional business logic can be added here (e.g., validation)
        return ownerDAO.insert(owner);
    }

    /**
     * Retrieves all owners from the system.
     *
     * @return A list of all owners.
     */
    public List<Owner> getAllOwners() {
        return ownerDAO.getAll();
    }

    /**
     * Retrieves an owner by their unique ID.
     *
     * @param id The unique identifier of the owner.
     * @return The Owner object if found, null otherwise.
     */
    public Owner getOwnerById(int id) {
        return ownerDAO.getById(id);
    }

    /**
     * Updates an existing owner's details.
     *
     * @param owner The Owner object with updated information.
     * @return True if the update was successful, false otherwise.
     */
    public boolean updateOwner(Owner owner) {
        // Additional business logic can be added here (e.g., validation)
        return ownerDAO.update(owner);
    }

    /**
     * Deletes an owner from the system.
     *
     * @param id The unique identifier of the owner to delete.
     * @return True if the deletion was successful, false otherwise.
     */
    public boolean deleteOwner(int id) {
        return ownerDAO.delete(id);
    }
}

package com.vehiclemanagement.services;

import com.vehiclemanagement.daos.InsuranceDAO;
import com.vehiclemanagement.models.Insurance;

import java.util.List;

/**
 * Service class for managing Insurance-related operations.
 */
public class InsuranceService {
    private final InsuranceDAO insuranceDAO;

    public InsuranceService() {
        this.insuranceDAO = new InsuranceDAO();
    }

    /**
     * Adds a new insurance policy to the system.
     *
     * @param insurance The Insurance object to add.
     * @return True if the insurance was added successfully, false otherwise.
     */
    public boolean addInsurance(Insurance insurance) {
        // Additional business logic can be added here (e.g., validation)
        return insuranceDAO.insert(insurance);
    }

    /**
     * Retrieves all insurance policies from the system.
     *
     * @return A list of all insurances.
     */
    public List<Insurance> getAllInsurances() {
        return insuranceDAO.getAll();
    }

    /**
     * Retrieves an insurance policy by its unique ID.
     *
     * @param id The unique identifier of the insurance.
     * @return The Insurance object if found, null otherwise.
     */
    public Insurance getInsuranceById(int id) {
        return insuranceDAO.getById(id);
    }

    /**
     * Updates an existing insurance policy's details.
     *
     * @param insurance The Insurance object with updated information.
     * @return True if the update was successful, false otherwise.
     */
    public boolean updateInsurance(Insurance insurance) {
        // Additional business logic can be added here (e.g., validation)
        return insuranceDAO.update(insurance);
    }

    /**
     * Deletes an insurance policy from the system.
     *
     * @param id The unique identifier of the insurance to delete.
     * @return True if the deletion was successful, false otherwise.
     */
    public boolean deleteInsurance(int id) {
        return insuranceDAO.delete(id);
    }
}

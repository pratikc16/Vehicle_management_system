package com.vehiclemanagement.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.vehiclemanagement.models.Driver;
import com.vehiclemanagement.utils.DatabaseConnection;

/**
 * Data Access Object (DAO) for Driver entity.
 * Handles all CRUD operations related to drivers.
 */
public class DriverDAO implements DAO<Driver> {

    private Connection connection;

    public DriverDAO() {
        connection = DatabaseConnection.getConnection();
    }

    /**
     * Inserts a new Driver into the database.
     *
     * @param driver The Driver object to insert.
     * @return True if insertion was successful, false otherwise.
     */
    @Override
    public boolean insert(Driver driver) {
        String sql = "INSERT INTO drivers (first_name, last_name, license_number, phone_number, email) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, driver.getFirstName());
            stmt.setString(2, driver.getLastName());
            stmt.setString(3, driver.getLicenseNumber());
            stmt.setString(4, driver.getPhoneNumber());
            stmt.setString(5, driver.getEmail());
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Inserting driver failed, no rows affected.");
            }
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    driver.setDriverId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Inserting driver failed, no ID obtained.");
                }
            }
            return true;
        } catch (SQLException e) {
            System.err.println("Error inserting driver: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves all Drivers from the database.
     *
     * @return A list of all Driver objects.
     */
    @Override
    public List<Driver> getAll() {
        List<Driver> drivers = new ArrayList<>();
        String sql = "SELECT * FROM drivers";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Driver driver = new Driver();
                driver.setDriverId(rs.getInt("driver_id"));
                driver.setFirstName(rs.getString("first_name"));
                driver.setLastName(rs.getString("last_name"));
                driver.setLicenseNumber(rs.getString("license_number"));
                driver.setPhoneNumber(rs.getString("phone_number"));
                driver.setEmail(rs.getString("email"));
                drivers.add(driver);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching drivers: " + e.getMessage());
        }
        return drivers;
    }

    /**
     * Retrieves a Driver by its ID.
     *
     * @param id The unique identifier of the Driver.
     * @return The Driver object if found, null otherwise.
     */
    @Override
    public Driver getById(int id) {
        String sql = "SELECT * FROM drivers WHERE driver_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Driver driver = new Driver();
                driver.setDriverId(rs.getInt("driver_id"));
                driver.setFirstName(rs.getString("first_name"));
                driver.setLastName(rs.getString("last_name"));
                driver.setLicenseNumber(rs.getString("license_number"));
                driver.setPhoneNumber(rs.getString("phone_number"));
                driver.setEmail(rs.getString("email"));
                return driver;
            }
        } catch (SQLException e) {
            System.err.println("Error fetching driver by ID: " + e.getMessage());
        }
        return null;
    }

    /**
     * Updates an existing Driver's details in the database.
     *
     * @param driver The Driver object with updated information.
     * @return True if update was successful, false otherwise.
     */
    @Override
    public boolean update(Driver driver) {
        String sql = "UPDATE drivers SET first_name = ?, last_name = ?, license_number = ?, phone_number = ?, email = ? WHERE driver_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, driver.getFirstName());
            stmt.setString(2, driver.getLastName());
            stmt.setString(3, driver.getLicenseNumber());
            stmt.setString(4, driver.getPhoneNumber());
            stmt.setString(5, driver.getEmail());
            stmt.setInt(6, driver.getDriverId());
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating driver: " + e.getMessage());
            return false;
        }
    }

    /**
     * Deletes a Driver from the database by its ID.
     *
     * @param id The unique identifier of the Driver to delete.
     * @return True if deletion was successful, false otherwise.
     */
    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM drivers WHERE driver_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting driver: " + e.getMessage());
            return false;
        }
    }
}

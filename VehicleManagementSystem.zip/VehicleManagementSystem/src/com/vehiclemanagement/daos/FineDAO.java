package com.vehiclemanagement.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.vehiclemanagement.models.Fine;
import com.vehiclemanagement.utils.DatabaseConnection;

/**
 * Data Access Object (DAO) for Fine entity.
 * Handles all CRUD operations related to fines.
 */
public class FineDAO implements DAO<Fine> {

    private Connection connection;

    public FineDAO() {
        connection = DatabaseConnection.getConnection();
    }

    /**
     * Inserts a new Fine into the database.
     *
     * @param fine The Fine object to insert.
     * @return True if insertion was successful, false otherwise.
     */
    @Override
    public boolean insert(Fine fine) {
        String sql = "INSERT INTO fines (vehicle_id, description, amount, date_issued) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, fine.getVehicleId());
            stmt.setString(2, fine.getDescription());
            stmt.setDouble(3, fine.getAmount());
            stmt.setDate(4, Date.valueOf(fine.getDateIssued()));
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Inserting fine failed, no rows affected.");
            }
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    fine.setFineId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Inserting fine failed, no ID obtained.");
                }
            }
            return true;
        } catch (SQLException e) {
            System.err.println("Error inserting fine: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves all Fines from the database.
     *
     * @return A list of all Fine objects.
     */
    @Override
    public List<Fine> getAll() {
        List<Fine> fines = new ArrayList<>();
        String sql = "SELECT * FROM fines";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Fine fine = new Fine();
                fine.setFineId(rs.getInt("fine_id"));
                fine.setVehicleId(rs.getInt("vehicle_id"));
                fine.setDescription(rs.getString("description"));
                fine.setAmount(rs.getDouble("amount"));
                fine.setDateIssued(rs.getDate("date_issued").toLocalDate());
                fines.add(fine);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching fines: " + e.getMessage());
        }
        return fines;
    }

    /**
     * Retrieves a Fine by its ID.
     *
     * @param id The unique identifier of the Fine.
     * @return The Fine object if found, null otherwise.
     */
    @Override
    public Fine getById(int id) {
        String sql = "SELECT * FROM fines WHERE fine_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Fine fine = new Fine();
                fine.setFineId(rs.getInt("fine_id"));
                fine.setVehicleId(rs.getInt("vehicle_id"));
                fine.setDescription(rs.getString("description"));
                fine.setAmount(rs.getDouble("amount"));
                fine.setDateIssued(rs.getDate("date_issued").toLocalDate());
                return fine;
            }
        } catch (SQLException e) {
            System.err.println("Error fetching fine by ID: " + e.getMessage());
        }
        return null;
    }

    /**
     * Updates an existing Fine's details in the database.
     *
     * @param fine The Fine object with updated information.
     * @return True if update was successful, false otherwise.
     */
    @Override
    public boolean update(Fine fine) {
        String sql = "UPDATE fines SET vehicle_id = ?, description = ?, amount = ?, date_issued = ? WHERE fine_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, fine.getVehicleId());
            stmt.setString(2, fine.getDescription());
            stmt.setDouble(3, fine.getAmount());
            stmt.setDate(4, Date.valueOf(fine.getDateIssued()));
            stmt.setInt(5, fine.getFineId());
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating fine: " + e.getMessage());
            return false;
        }
    }

    /**
     * Deletes a Fine from the database by its ID.
     *
     * @param id The unique identifier of the Fine to delete.
     * @return True if deletion was successful, false otherwise.
     */
    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM fines WHERE fine_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting fine: " + e.getMessage());
            return false;
        }
    }
}

package com.vehiclemanagement.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.vehiclemanagement.models.Insurance;
import com.vehiclemanagement.utils.DatabaseConnection;

public class InsuranceDAO implements DAO<Insurance> {

    private Connection connection;

    public InsuranceDAO() {
        connection = DatabaseConnection.getConnection();
    }

    @Override
    public boolean insert(Insurance insurance) {
        String sql = "INSERT INTO insurances (vehicle_id, insurance_company, coverage_amount, start_date, end_date, policy_number) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, insurance.getVehicleId());
            stmt.setString(2, insurance.getInsuranceCompany());
            stmt.setDouble(3, insurance.getCoverageAmount());
            stmt.setDate(4, Date.valueOf(insurance.getStartDate()));
            stmt.setDate(5, Date.valueOf(insurance.getEndDate()));
            stmt.setString(6, insurance.getPolicyNumber());
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Inserting insurance failed, no rows affected.");
            }
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    insurance.setInsuranceId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Inserting insurance failed, no ID obtained.");
                }
            }
            return true;
        } catch (SQLException e) {
            System.err.println("Error inserting insurance: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<Insurance> getAll() {
        List<Insurance> insurances = new ArrayList<>();
        String sql = "SELECT * FROM insurances";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Insurance insurance = new Insurance();
                insurance.setInsuranceId(rs.getInt("insurance_id"));
                insurance.setVehicleId(rs.getInt("vehicle_id"));
                insurance.setInsuranceCompany(rs.getString("insurance_company"));
                insurance.setCoverageAmount(rs.getDouble("coverage_amount"));
                insurance.setStartDate(rs.getDate("start_date").toLocalDate());
                insurance.setEndDate(rs.getDate("end_date").toLocalDate());
                insurance.setPolicyNumber(rs.getString("policy_number"));
                insurances.add(insurance);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching insurances: " + e.getMessage());
        }
        return insurances;
    }

    @Override
    public Insurance getById(int id) {
        String sql = "SELECT * FROM insurances WHERE insurance_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Insurance insurance = new Insurance();
                insurance.setInsuranceId(rs.getInt("insurance_id"));
                insurance.setVehicleId(rs.getInt("vehicle_id"));
                insurance.setInsuranceCompany(rs.getString("insurance_company"));
                insurance.setCoverageAmount(rs.getDouble("coverage_amount"));
                insurance.setStartDate(rs.getDate("start_date").toLocalDate());
                insurance.setEndDate(rs.getDate("end_date").toLocalDate());
                insurance.setPolicyNumber(rs.getString("policy_number"));
                return insurance;
            }
        } catch (SQLException e) {
            System.err.println("Error fetching insurance by ID: " + e.getMessage());
        }
        return null;
    }

    @Override
    public boolean update(Insurance insurance) {
        String sql = "UPDATE insurances SET vehicle_id = ?, insurance_company = ?, coverage_amount = ?, start_date = ?, end_date = ?, policy_number = ? WHERE insurance_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, insurance.getVehicleId());
            stmt.setString(2, insurance.getInsuranceCompany());
            stmt.setDouble(3, insurance.getCoverageAmount());
            stmt.setDate(4, Date.valueOf(insurance.getStartDate()));
            stmt.setDate(5, Date.valueOf(insurance.getEndDate()));
            stmt.setString(6, insurance.getPolicyNumber());
            stmt.setInt(7, insurance.getInsuranceId());
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating insurance: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM insurances WHERE insurance_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting insurance: " + e.getMessage());
            return false;
        }
    }
}

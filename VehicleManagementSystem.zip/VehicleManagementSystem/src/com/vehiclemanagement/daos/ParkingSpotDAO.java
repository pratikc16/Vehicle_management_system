// File: src/com/vehiclemanagement/daos/ParkingSpotDAO.java

package com.vehiclemanagement.daos;

import com.vehiclemanagement.models.ParkingSpot;
import com.vehiclemanagement.utils.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ParkingSpotDAO implements DAO<ParkingSpot> {

    private Connection connection;

    public ParkingSpotDAO() {
        connection = DatabaseConnection.getConnection();
    }

    @Override
    public boolean insert(ParkingSpot spot) {
        String sql = "INSERT INTO parking_spots (location, latitude, longitude, availability) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, spot.getLocation());
            stmt.setDouble(2, spot.getLatitude());
            stmt.setDouble(3, spot.getLongitude());
            stmt.setBoolean(4, spot.isAvailability());
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error inserting parking spot: " + e.getMessage());
            return false;
        }
    }

    @Override
    public ParkingSpot get(int id) {
        String sql = "SELECT * FROM parking_spots WHERE spot_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                ParkingSpot spot = new ParkingSpot();
                spot.setSpotId(rs.getInt("spot_id"));
                spot.setLocation(rs.getString("location"));
                spot.setLatitude(rs.getDouble("latitude"));
                spot.setLongitude(rs.getDouble("longitude"));
                spot.setAvailability(rs.getBoolean("availability"));
                return spot;
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving parking spot: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<ParkingSpot> getAll() {
        List<ParkingSpot> spots = new ArrayList<>();
        String sql = "SELECT * FROM parking_spots";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                ParkingSpot spot = new ParkingSpot();
                spot.setSpotId(rs.getInt("spot_id"));
                spot.setLocation(rs.getString("location"));
                spot.setLatitude(rs.getDouble("latitude"));
                spot.setLongitude(rs.getDouble("longitude"));
                spot.setAvailability(rs.getBoolean("availability"));
                spots.add(spot);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving parking spots: " + e.getMessage());
        }
        return spots;
    }

    @Override
    public boolean update(ParkingSpot spot) {
        String sql = "UPDATE parking_spots SET location = ?, latitude = ?, longitude = ?, availability = ? WHERE spot_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, spot.getLocation());
            stmt.setDouble(2, spot.getLatitude());
            stmt.setDouble(3, spot.getLongitude());
            stmt.setBoolean(4, spot.isAvailability());
            stmt.setInt(5, spot.getSpotId());
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating parking spot: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM parking_spots WHERE spot_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting parking spot: " + e.getMessage());
            return false;
        }
    }
}

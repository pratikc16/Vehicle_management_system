package com.vehiclemanagement.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.vehiclemanagement.models.Vehicle;
import com.vehiclemanagement.utils.DatabaseConnection;

/**
 * Data Access Object (DAO) for Vehicle entity.
 * Handles all CRUD operations related to vehicles.
 */
public class VehicleDAO implements DAO<Vehicle> {

    private Connection connection;

    public VehicleDAO() {
        connection = DatabaseConnection.getConnection();
    }

    /**
     * Inserts a new Vehicle into the database.
     *
     * @param vehicle The Vehicle object to insert.
     * @return True if insertion was successful, false otherwise.
     */
    @Override
    public boolean insert(Vehicle vehicle) {
        String sql = "INSERT INTO vehicles (owner_id, make, model, year, license_plate, color, driver_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, vehicle.getOwnerId());
            stmt.setString(2, vehicle.getMake());
            stmt.setString(3, vehicle.getModel());
            stmt.setInt(4, vehicle.getYear());
            stmt.setString(5, vehicle.getLicensePlate());
            stmt.setString(6, vehicle.getColor());
            stmt.setInt(7, vehicle.getDriverId());
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Inserting vehicle failed, no rows affected.");
            }
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    vehicle.setVehicleId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Inserting vehicle failed, no ID obtained.");
                }
            }
            return true;
        } catch (SQLException e) {
            System.err.println("Error inserting vehicle: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves all Vehicles from the database.
     *
     * @return A list of all Vehicle objects.
     */
    @Override
    public List<Vehicle> getAll() {
        List<Vehicle> vehicles = new ArrayList<>();
        String sql = "SELECT * FROM vehicles";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Vehicle vehicle = new Vehicle();
                vehicle.setVehicleId(rs.getInt("vehicle_id"));
                vehicle.setOwnerId(rs.getInt("owner_id"));
                vehicle.setMake(rs.getString("make"));
                vehicle.setModel(rs.getString("model"));
                vehicle.setYear(rs.getInt("year"));
                vehicle.setLicensePlate(rs.getString("license_plate"));
                vehicle.setColor(rs.getString("color"));
                vehicle.setDriverId(rs.getInt("driver_id"));
                vehicles.add(vehicle);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching vehicles: " + e.getMessage());
        }
        return vehicles;
    }

    /**
     * Retrieves a Vehicle by its ID.
     *
     * @param id The unique identifier of the Vehicle.
     * @return The Vehicle object if found, null otherwise.
     */
    @Override
    public Vehicle getById(int id) {
        String sql = "SELECT * FROM vehicles WHERE vehicle_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Vehicle vehicle = new Vehicle();
                vehicle.setVehicleId(rs.getInt("vehicle_id"));
                vehicle.setOwnerId(rs.getInt("owner_id"));
                vehicle.setMake(rs.getString("make"));
                vehicle.setModel(rs.getString("model"));
                vehicle.setYear(rs.getInt("year"));
                vehicle.setLicensePlate(rs.getString("license_plate"));
                vehicle.setColor(rs.getString("color"));
                vehicle.setDriverId(rs.getInt("driver_id"));
                return vehicle;
            }
        } catch (SQLException e) {
            System.err.println("Error fetching vehicle by ID: " + e.getMessage());
        }
        return null;
    }

    /**
     * Updates an existing Vehicle's details in the database.
     *
     * @param vehicle The Vehicle object with updated information.
     * @return True if update was successful, false otherwise.
     */
    @Override
    public boolean update(Vehicle vehicle) {
        String sql = "UPDATE vehicles SET owner_id = ?, make = ?, model = ?, year = ?, license_plate = ?, color = ?, driver_id = ? WHERE vehicle_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, vehicle.getOwnerId());
            stmt.setString(2, vehicle.getMake());
            stmt.setString(3, vehicle.getModel());
            stmt.setInt(4, vehicle.getYear());
            stmt.setString(5, vehicle.getLicensePlate());
            stmt.setString(6, vehicle.getColor());
            stmt.setInt(7, vehicle.getDriverId());
            stmt.setInt(8, vehicle.getVehicleId());
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating vehicle: " + e.getMessage());
            return false;
        }
    }

    /**
     * Deletes a Vehicle from the database by its ID.
     *
     * @param id The unique identifier of the Vehicle to delete.
     * @return True if deletion was successful, false otherwise.
     */
    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM vehicles WHERE vehicle_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting vehicle: " + e.getMessage());
            return false;
        }
    }
}

package com.vehiclemanagement.daos;

import java.util.List;

/**
 * Generic Data Access Object (DAO) interface defining standard CRUD operations.
 *
 * @param <T> The type of the entity.
 */
public interface DAO<T> {
    
    /**
     * Inserts a new entity into the database.
     *
     * @param t The entity to insert.
     * @return True if the insertion was successful, false otherwise.
     */
    boolean insert(T t);
    
    /**
     * Retrieves all entities from the database.
     *
     * @return A list of all entities.
     */
    List<T> getAll();
    
    /**
     * Retrieves an entity by its unique identifier.
     *
     * @param id The unique identifier of the entity.
     * @return The entity if found, null otherwise.
     */
    T getById(int id);
    
    /**
     * Updates an existing entity in the database.
     *
     * @param t The entity with updated information.
     * @return True if the update was successful, false otherwise.
     */
    boolean update(T t);
    
    /**
     * Deletes an entity from the database by its unique identifier.
     *
     * @param id The unique identifier of the entity to delete.
     * @return True if the deletion was successful, false otherwise.
     */
    boolean delete(int id);
}

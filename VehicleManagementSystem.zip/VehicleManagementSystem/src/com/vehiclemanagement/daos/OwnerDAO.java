package com.vehiclemanagement.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.vehiclemanagement.models.Owner;
import com.vehiclemanagement.utils.DatabaseConnection;

/**
 * Data Access Object (DAO) for Owner entity.
 * Handles all CRUD operations related to owners.
 */
public class OwnerDAO implements DAO<Owner> {

    private Connection connection;

    public OwnerDAO() {
        connection = DatabaseConnection.getConnection();
    }

    /**
     * Inserts a new Owner into the database.
     *
     * @param owner The Owner object to insert.
     * @return True if insertion was successful, false otherwise.
     */
    @Override
    public boolean insert(Owner owner) {
        String sql = "INSERT INTO owners (first_name, last_name, address, phone_number, email) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, owner.getFirstName());
            stmt.setString(2, owner.getLastName());
            stmt.setString(3, owner.getAddress());
            stmt.setString(4, owner.getPhoneNumber());
            stmt.setString(5, owner.getEmail());
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Inserting owner failed, no rows affected.");
            }
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    owner.setOwnerId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Inserting owner failed, no ID obtained.");
                }
            }
            return true;
        } catch (SQLException e) {
            System.err.println("Error inserting owner: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves all Owners from the database.
     *
     * @return A list of all Owner objects.
     */
    @Override
    public List<Owner> getAll() {
        List<Owner> owners = new ArrayList<>();
        String sql = "SELECT * FROM owners";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Owner owner = new Owner();
                owner.setOwnerId(rs.getInt("owner_id"));
                owner.setFirstName(rs.getString("first_name"));
                owner.setLastName(rs.getString("last_name"));
                owner.setAddress(rs.getString("address"));
                owner.setPhoneNumber(rs.getString("phone_number"));
                owner.setEmail(rs.getString("email"));
                owners.add(owner);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching owners: " + e.getMessage());
        }
        return owners;
    }

    /**
     * Retrieves an Owner by their ID.
     *
     * @param id The unique identifier of the Owner.
     * @return The Owner object if found, null otherwise.
     */
    @Override
    public Owner getById(int id) {
        String sql = "SELECT * FROM owners WHERE owner_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Owner owner = new Owner();
                owner.setOwnerId(rs.getInt("owner_id"));
                owner.setFirstName(rs.getString("first_name"));
                owner.setLastName(rs.getString("last_name"));
                owner.setAddress(rs.getString("address"));
                owner.setPhoneNumber(rs.getString("phone_number"));
                owner.setEmail(rs.getString("email"));
                return owner;
            }
        } catch (SQLException e) {
            System.err.println("Error fetching owner by ID: " + e.getMessage());
        }
        return null;
    }

    /**
     * Updates an existing Owner's details in the database.
     *
     * @param owner The Owner object with updated information.
     * @return True if update was successful, false otherwise.
     */
    @Override
    public boolean update(Owner owner) {
        String sql = "UPDATE owners SET first_name = ?, last_name = ?, address = ?, phone_number = ?, email = ? WHERE owner_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, owner.getFirstName());
            stmt.setString(2, owner.getLastName());
            stmt.setString(3, owner.getAddress());
            stmt.setString(4, owner.getPhoneNumber());
            stmt.setString(5, owner.getEmail());
            stmt.setInt(6, owner.getOwnerId());
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating owner: " + e.getMessage());
            return false;
        }
    }

    /**
     * Deletes an Owner from the database by their ID.
     *
     * @param id The unique identifier of the Owner to delete.
     * @return True if deletion was successful, false otherwise.
     */
    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM owners WHERE owner_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting owner: " + e.getMessage());
            return false;
        }
    }
}

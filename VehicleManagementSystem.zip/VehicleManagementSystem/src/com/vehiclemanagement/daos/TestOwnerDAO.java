// File: src/com/vehiclemanagement/daos/TestOwnerDAO.java

package com.vehiclemanagement.daos;

import com.vehiclemanagement.models.Owner;

import java.util.List;

public class TestOwnerDAO {
    public static void main(String[] args) {
        OwnerDAO ownerDAO = new OwnerDAO();

        // Create a new owner
        Owner newOwner = new Owner();
        newOwner.setFirstName("John");
        newOwner.setLastName("Doe");
        newOwner.setAddress("123 Main St");
        newOwner.setPhoneNumber("555-1234");
        newOwner.setEmail("johndoe@example.com");

        boolean insertResult = ownerDAO.insert(newOwner);
        System.out.println("Insert result: " + insertResult);

        // Retrieve all owners
        List<Owner> owners = ownerDAO.getAll();
        System.out.println("Owners in database:");
        for (Owner owner : owners) {
            System.out.println(owner);
        }

        // Update an owner
        if (!owners.isEmpty()) {
            Owner ownerToUpdate = owners.get(0);
            ownerToUpdate.setAddress("456 Elm St");
            boolean updateResult = ownerDAO.update(ownerToUpdate);
            System.out.println("Update result: " + updateResult);
        }

        // Delete an owner
        if (!owners.isEmpty()) {
            int ownerIdToDelete = owners.get(0).getOwnerId();
            boolean deleteResult = ownerDAO.delete(ownerIdToDelete);
            System.out.println("Delete result: " + deleteResult);
        }
    }
}

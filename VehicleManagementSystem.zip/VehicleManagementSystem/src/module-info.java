module VehicleManagementSystem {
    // Required modules
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
	requires javafx.base;

    // Opens packages to JavaFX for FXML loading and controller access
    opens com.vehiclemanagement.gui to javafx.fxml;
    opens com.vehiclemanagement.models to javafx.base;

    // Exports packages for access by other modules (if necessary)
    exports com.vehiclemanagement.gui;
    exports com.vehiclemanagement.models;
    exports com.vehiclemanagement.daos;
    exports com.vehiclemanagement.services;
}
